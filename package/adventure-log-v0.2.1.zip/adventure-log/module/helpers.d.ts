/**
 * General helper methods
 */
declare enum ErrorLevels {
    Debug = 0,
    Low = 1,
    Medium = 2,
    High = 3,
    Critical = 4
}
export declare function customLog(text: string, level?: ErrorLevels): void;
export declare function loadData(): any;
export declare function unFlatten(data: any): any;
export {};
