/// <reference types="jquery" />
import { TemplatedFolder } from "./templated-folder";
/**
 * Edit a folder, configuring its name and appearance
 * @extends {FormApplication}
 */
export declare class TemplFolderConfig extends FormApplication {
    /** @override */
    static get defaultOptions(): FormApplicationOptions;
    /** @override */
    get id(): string;
    /** @override */
    get title(): string;
    /** @override */
    getData(options: any): Promise<{
        folder: EntityData<any>;
        templFolder: import("./templated-folder").TemplateSettings;
        sortingModes: {
            a: string;
            m: string;
        };
        submitText: string;
        editing: boolean;
    }>;
    /** @override */
    _updateObject(event: Event, formData: any): Promise<void>;
    storeCustom(formData: any): void;
    /** @override */
    activateListeners(html: JQuery): void;
}
export interface TemplFolderConfig extends FormApplication {
    object: TemplatedFolder;
}
