/**
 * General helper methods
 */
import { MODULE_ID, MODULE_NAME, Settings } from "./constants.js";
// For more consistent error handling
var ErrorLevels;
(function (ErrorLevels) {
    ErrorLevels[ErrorLevels["Debug"] = 0] = "Debug";
    ErrorLevels[ErrorLevels["Low"] = 1] = "Low";
    ErrorLevels[ErrorLevels["Medium"] = 2] = "Medium";
    ErrorLevels[ErrorLevels["High"] = 3] = "High";
    ErrorLevels[ErrorLevels["Critical"] = 4] = "Critical";
})(ErrorLevels || (ErrorLevels = {}));
export function customLog(text, level = 0) {
    const prefix = `${MODULE_NAME} |`;
    switch (level) {
        case ErrorLevels["Debug"]:
            if (game.settings.get(MODULE_ID, `${MODULE_ID}.${Settings.debug}`)) {
                console.log(`${prefix} Debug: ${text}`);
            }
            break;
        case ErrorLevels["Low"]:
            console.log(`${prefix} Warning: ${text}`);
            break;
        case ErrorLevels["Medium"]:
            console.warn(`${prefix} Error: ${text}`);
            ui.notifications.warn(`Warning - ${text}`);
            break;
        case ErrorLevels["High"]:
            console.error(`${prefix} Error: ${text}`);
            ui.notifications.error(`Error - ${text}`);
            break;
        case ErrorLevels["Critical"]:
            console.error(`${prefix} Error: ${text}`);
            ui.notifications.error(`Critical Error! - ${text}`);
            throw `${prefix} Error: ${text}`;
            break;
    }
}
export function loadData() {
    return game.settings.get(MODULE_ID, `${MODULE_ID}.${Settings.templates}`);
}

//# sourceMappingURL=helpers.js.map
