/// <reference types="jquery" />
/**
 * Pseudo-class for use on all templated folder actions
 * Currently we aren't using the extension, but perhaps in the future
 */
export declare class TemplatedFolder extends Folder {
    /**
     * Assigns all custom TemplatedFolder properties to the given folder
     * @param folder Folder that should be treated as a TemplatedFolder after setup
     */
    static customProperties(folder: Folder): void;
    /**
     * On templated button click. For template creation
     * @param event	ClickEvent for the stamp button
     */
    static buttonClick(event: JQuery.ClickEvent): void;
    /**
     * Given a folder's header, perform all necessary setup to convert it to a templated folder
     * @param header Standard HTML header for the folder
     */
    static convertFolder(header: JQuery<HTMLElement>): void;
    delete(options?: object | undefined): Promise<string>;
}
export interface TemplatedFolder extends Folder {
    testFunc?: Function;
    isTemplated: boolean;
}
