export const MODULE_ID = "adventure-log";
export const MODULE_NAME = "adventure-log";
export const MODULE_ABBREV = "ADVL";
export var Settings;
(function (Settings) {
    Settings["debug"] = "debug";
    Settings["templates"] = "templates";
})(Settings || (Settings = {}));

//# sourceMappingURL=constants.js.map
