/// <reference types="jquery" />
export declare class SetupManager {
    static overrideFuncs(): void;
    static customProperties(): void;
    /**
     * Sets up right-click menu to add a "Create Templated Folder" option, which performs creation actions on the given folder
     * @param html 		HTML Given from hook, sidebar HTML
     * @param options 	Options from hook containing all right-click menu items
     */
    static setMenu(html: JQuery, options: any[]): void;
    /**
     * Performs all setup actions desired when journals are rendered
     * @param app 	Page Application
     * @param html 	Page HTML
     * @param data 	Page data
     */
    static onJournalsRendered(app: Application, html: JQuery, data: EntityData): void;
    /**
     * Adds a button to folder to create entry from template
     * @param app 	Application from hook
     * @param html 	HTML from hook. Expected to be sidebar html
     * @param data 	Given data, unclear what context it is
     */
    static addTemplateButton(app: Application, html: JQuery, data: EntityData): void;
    /**
     * Assigns CSS classes to all templated folders
     * @param html HTML to search for templates in
     */
    static setClasses(html: JQuery<HTMLElement>): void;
    /**
     * Function to clean up any folders that may no longer exist from our data
     * GM-only
     */
    static cleanupData(): void;
}
