export const preloadTemplates = async function () {
    const templatePaths = [
    // Add paths to "modules/foundryvtt-adventure-log/templates"
    ];
    return loadTemplates(templatePaths);
};

//# sourceMappingURL=preloadTemplates.js.map
