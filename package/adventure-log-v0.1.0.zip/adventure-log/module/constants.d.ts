export declare const MODULE_ID = "adventure-log";
export declare const MODULE_NAME = "adventure-log";
export declare const MODULE_ABBREV = "ADVL";
export declare enum Settings {
    debug = "debug",
    templates = "templates"
}
