/// <reference types="jquery" />
import { TemplFolderConfig } from "./templ-folder-config";
/**
 * An instance of a folder with template information set.
 */
export declare class TemplatedFolder extends Folder {
    /**
     * On templated button click. For template creation
     * @param event	ClickEvent for the stamp button
     */
    static buttonClick(event: JQuery.ClickEvent): void;
    static convertFromButton(header: JQuery<HTMLElement>): Promise<void>;
    /**
     * Given a folder's header, perform all necessary setup to convert it to a templated folder
     * @param header Standard HTML header for the folder
     */
    static convertFolder(folder: Folder): Promise<TemplatedFolder>;
    /**
     * Create a new Folder in this SidebarDirectory
     * @param {MouseEvent} event    The originating button click event
     * @private
     */
    static _onCreateTemplatedFolder(event: Event): void;
    constructor(folder: Folder);
    isTemplated: boolean;
    template: JournalEntry;
    get templateSettings(): TemplateSettings;
    setOptions(settings: TemplateSettings): Promise<void>;
    /**
     * Create a new Templated Folder w/ dialog to set options
     * @param {object} data       Initial data with which to populate the creation form
     * @param {object} options    Initial positioning and sizing options for the dialog form
     * @return {FolderConfig}     An active FolderConfig instance for creating the new Folder entity
     */
    static createDialog(data?: object, options?: object): Promise<TemplFolderConfig>;
}
export declare let defaultSettings: TemplateSettings;
export interface TemplatedFolder extends Folder {
    testFunc?: Function;
    isTemplated: boolean;
    template: JournalEntry;
    templateSettings: TemplateSettings;
}
export interface TemplateSettings {
    newEntryName: string;
    newPerms: number;
    playerCreation: boolean;
}
