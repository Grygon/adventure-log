export declare const preloadTemplates: () => Promise<void>;
