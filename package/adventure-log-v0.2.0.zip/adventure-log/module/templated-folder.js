import { customLog, loadData } from "./helpers.js";
import { MODULE_ID, Settings } from "./constants.js";
import { TemplFolderConfig } from "./templ-folder-config.js";
/**
 * An instance of a folder with template information set.
 */
export class TemplatedFolder extends Folder {
    constructor(folder) {
        super(folder.data, {});
        this.isTemplated = true;
        let curTemplates = loadData();
        this.template = game.journal.get(curTemplates[folder.id]);
        game.folders.set(this.id, this);
    }
    /**
     * On templated button click. For template creation
     * @param event	ClickEvent for the stamp button
     */
    static buttonClick(event) {
        var _a;
        const button = event.currentTarget;
        const folderEL = (_a = button === null || button === void 0 ? void 0 : button.parentElement) === null || _a === void 0 ? void 0 : _a.parentElement;
        let folderID = folderEL === null || folderEL === void 0 ? void 0 : folderEL.dataset["folderId"];
        let folder = game.folders.get(folderID);
        customLog(`Folder ${folder.id} activated with template ${folder.template.id}`);
        let template = folder.template;
        let data = {
            name: folder.templateSettings.newEntryName,
            type: "Journal",
            folder: folderID,
            // Data doesn't seem to be working anyway so I'm going to leave it blank, at least for now
            data: {},
            permission: { default: Number(folder.templateSettings.newPerms) },
        };
        let title = "New Templated Entry";
        // Render the entity creation form
        renderTemplate(`templates/sidebar/entity-create.html`, {
            //@ts-ignore
            name: data.name || game.i18n.format("ENTITY.New"),
            folder: data.folder,
            type: data.type,
        }).then((html) => {
            // Render the confirmation dialog window
            //@ts-ignore
            return Dialog.prompt({
                title: title,
                content: html,
                label: title,
                callback: (html) => {
                    const form = html[0].querySelector("form");
                    //@ts-ignore
                    const fd = new FormDataExtended(form).toObject();
                    if (!fd["name"])
                        delete fd["name"];
                    data = mergeObject(data, fd);
                    JournalEntry.create(data).then((newEntry) => {
                        newEntry
                            .update({
                            content: template.data.content,
                        })
                            .then((arg) => {
                            // Future-proofing a bit here
                            newEntry.setFlag(MODULE_ID, "template", template.id);
                            newEntry.sheet.render(true);
                        });
                    });
                },
            });
        });
    }
    static async convertFromButton(header) {
        let folderID = header.parent()[0].dataset["folderId"];
        if (!folderID) {
            customLog("Error converting folder--ID does not exist", 2);
            return;
        }
        let folder = game.folders.get(folderID);
        this.convertFolder(folder);
    }
    /**
     * Given a folder's header, perform all necessary setup to convert it to a templated folder
     * @param header Standard HTML header for the folder
     */
    static async convertFolder(folder) {
        customLog(`Converting folder ${folder.id}`);
        folder.update({
            sorting: "m",
        });
        let data = {
            name: "Template",
            type: "Journal",
            folder: folder.id,
            // Data doesn't seem to be working anyway so I'm going to leave it blank, at least for now
            data: {
                sort: -999999,
            },
        };
        let template = await JournalEntry.create(data);
        let templateID = template.id;
        customLog(`Template ${templateID} created for folder ${folder.id}`);
        // Future-proofing a bit here
        await template.setFlag(MODULE_ID, "templateFolder", folder.id);
        template.sheet.render(true);
        // Current templates object
        let curTemplates = loadData();
        curTemplates[folder.id] = templateID;
        await game.settings.set(MODULE_ID, `${MODULE_ID}.${Settings.templates}`, curTemplates);
        let tFolder = new TemplatedFolder(folder);
        await tFolder.setOptions(defaultSettings);
        customLog(`Template registered to folder`);
        return tFolder;
    }
    /**
     * Create a new Folder in this SidebarDirectory
     * @param {MouseEvent} event    The originating button click event
     * @private
     */
    static _onCreateTemplatedFolder(event) {
        event.preventDefault();
        event.stopPropagation();
        const button = event.currentTarget;
        if (!button || !(button instanceof HTMLButtonElement)) {
            customLog("Button doesn't exist, how did you get here?", 3);
            return;
        }
        const parent = button.dataset.parentFolder;
        const data = {
            parent: parent ? parent : null,
            type: "JournalEntry",
        };
        const options = {
            top: button.offsetTop,
            left: window.innerWidth -
                310 -
                Number(FolderConfig.defaultOptions.width),
        };
        //@ts-ignore Folder does have createDialog, despiite popular opinion
        TemplatedFolder.createDialog(data, options);
    }
    get templateSettings() {
        return this.getFlag(MODULE_ID, "settings");
    }
    async setOptions(settings) {
        let curSettings = {};
        if (this.templateSettings) {
            curSettings = this.templateSettings;
        }
        await this.setFlag(MODULE_ID, "settings", mergeObject(curSettings, settings));
        customLog(`Folder ${this.id} settings data updated`);
    }
    /**
     * Create a new Templated Folder w/ dialog to set options
     * @param {object} data       Initial data with which to populate the creation form
     * @param {object} options    Initial positioning and sizing options for the dialog form
     * @return {FolderConfig}     An active FolderConfig instance for creating the new Folder entity
     */
    static async createDialog(data = {}, options = {}) {
        const folder = new Folder(mergeObject({ sorting: "m" }, data), {});
        //@ts-ignore
        let config = new TemplFolderConfig(folder, mergeObject({ creating: true }, options));
        await config.render(true);
        return config;
    }
}
// Set default options
export let defaultSettings = {
    newEntryName: "New Entry",
    // Oberver permissions by default
    newPerms: 2,
    playerCreation: true,
};

//# sourceMappingURL=templated-folder.js.map
