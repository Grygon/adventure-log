export declare const registerSettings: () => void;
