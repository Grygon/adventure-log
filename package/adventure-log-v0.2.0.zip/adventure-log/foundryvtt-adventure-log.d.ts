/**
 * Module to allow easy templated folders for GM and Player use
 * Author: Grygon
 * Software License: MIT
 */
export {};
